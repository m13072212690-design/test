default chappy_input=""


label open_chappy:

    while True:

        call screen chappy_search

        if _return == "input":

            $ chappy_input = renpy.input(
                "请输入搜索内容：",
                default=chappy_input,
                length=50
            ).strip()


        elif _return == "search":

            if chappy_search_function():

                return


        elif _return == "close":

            return


screen chappy_search():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5


        vbox:

            spacing 20

            xalign 0.5
            yalign 0.5


            text "小雾同学正在深度思考中......":

                xalign 0.5
                text_align 0.5


            add "chappy_logo":

                xalign 0.5


            # 模拟输入框
            button:

                xsize 600
                ysize 60

                xalign 0.5

                action Return("input")

                frame:

                    xfill True
                    yfill True

                    text (chappy_input if chappy_input else "点击这里输入搜索内容"):

                        xalign 0.5
                        yalign 0.5


            textbutton "Search":

                xalign 0.5

                action Return("search")


    textbutton "X":

        xpos 1120
        ypos 50

        action Return("close")

init python:

    def chappy_search_function():

        keyword = store.chappy_input.strip().lower()


        if keyword in clue_database:

            page = clue_database[keyword]

            renpy.call(page)

            return True


        else:

            renpy.notify(
                "无效的输入关键词"
            )

            return False
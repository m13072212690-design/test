default chappy_input=""

label open_chappy:

    call screen chappy_search

    return

screen chappy_search():

    modal True


    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5


        vbox:

            spacing 20

            xalign 0.5
            yalign 0.5


            text "欢迎使用Chappy，请问您有什么想问的吗":

                xalign 0.5
                text_align 0.5


            add "chappy_logo":

                xalign 0.5



            input:

                value VariableInputValue(
                    "chappy_input"
                )

                xsize 600

                xalign 0.5



            textbutton "Search":

                xalign 0.5

                action Function(
                    chappy_search_function
                )



    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

init python:


    def chappy_search_function():


        keyword = chappy_input.lower()



        if keyword in clue_database:


            page = clue_database[keyword]


            renpy.hide_screen(
                "chappy_search"
            )


            renpy.call(page)



        else:

            renpy.notify(
                "无效的输入关键词"
            )
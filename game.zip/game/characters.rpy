# characters.rpy

define saki = Character(
    "望月 咲",
    color="#ffffff"
)


define rei = Character(
    "霧谷 玲衣",
    color="#66ccff"
)


define yuika = Character(
    "小山内 唯香",
    color="#ffcc00"
)

define allc = Character(
    "全",
    color="#000000"
)

define unknown = Character(
    "?????",
    color="#000000"
)

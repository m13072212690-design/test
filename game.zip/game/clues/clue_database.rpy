init python:


    clue_database = {
        "小山内唯香": "yuika_clue",
        "mari": "mari_clue",
        "负鼠乐队": "opos_clue",
        "车祸": "traffic_clue",
        "秋野沙理": "sari_clue",
        "关东高校弓道大赛": "yumi_clue",
        "sakuranooka.forum" : "open_forum",
    }
default forum_search_text = ""
default forum_search_keyword = ""
label open_forum:

    while True:

        call screen forum_information


        # 点击搜索输入框
        if _return == "input":

            $ forum_search_text = renpy.input(
                "请输入搜索关键词：",
                default=forum_search_text,
                length=50
            ).strip()


        # 点击搜索按钮
        elif _return == "search":

            $ forum_search_keyword = forum_search_text.strip()

            # 继续循环，重新显示论坛页面
            # 此时 forum_search_keyword 已更新，
            # 下方内容区域会显示搜索结果。


        # 点击右上角 X
        elif _return == "close":

            return



screen forum_information():

    # 整个页面
    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        background "#ffffff"

        # ==================================================
        # 左侧区域
        # ==================================================

        frame:

            xpos 0
            ypos 0

            xsize 250
            ysize 640

            background "#f9dfe7"

            # 标题区域
            vbox:

                xpos 25
                ypos 150

                spacing 8

                text "樱之丘高校":

                    size 28
                    color "#5c3a45"
                    bold True

                text "学生论坛":

                    size 28
                    color "#5c3a45"
                    bold True

                null height 20

                text "SAKURANOOKA":

                    size 14
                    color "#9b7180"

                text "HIGH SCHOOL":

                    size 14
                    color "#9b7180"


        # ==================================================
        # 右侧整体区域
        # ==================================================

        frame:

            xpos 250
            ypos 0

            xsize 830
            ysize 640

            background "#ffffff"


            # ==================================================
            # 顶部搜索栏
            # ==================================================

            frame:

                xpos 0
                ypos 0

                xsize 830
                ysize 75

                background "#ffffff"


                # 搜索输入框

                button:

                    xpos 25
                    ypos 17

                    xsize 650
                    ysize 42

                    background "#f5f5f5"

                    action Return("input")


                    if forum_search_text:

                        text forum_search_text:

                            xpos 15
                            yalign 0.5

                            size 20

                            color "#333333"

                    else:

                        text "点击输入搜索关键词":

                            xpos 15
                            yalign 0.5

                            size 20

                            color "#999999"



                # 搜索按钮

                textbutton "搜索":

                    xpos 690
                    ypos 17

                    xsize 110
                    ysize 42

                    text_size 18

                    text_color "#ffffff"

                    background "#e69aaa"
                    hover_background "#d98294"

                    action Return("search")


            # ==================================================
            # 搜索栏下面的内容区域
            # ==================================================

            frame:

                xpos 0
                ypos 75

                xsize 830
                ysize 555

                background "#fafafa"


                # 根据关键词决定显示什么
                if forum_search_keyword == "":

                    # ------------------------------------------
                    # 默认内容
                    # ------------------------------------------

                    viewport:

                        xpos 0
                        ypos 0

                        xsize 840
                        ysize 565

                        scrollbars "vertical"

                        mousewheel True
                        draggable True

                        vbox:

                            xsize 810

                            xpos 20

                            spacing 15

                            # ==================================
                            # 默认内容从这里开始
                            # ==================================

                            text "校园论坛":

                                size 24
                                color "#444444"
                                bold True

                            frame:

                                xsize 810
                                ysize 120

                                background "#ffffff"

                                vbox:

                                    xpos 20
                                    ypos 15

                                    spacing 8

                                    text "【公告】 我校荣获第17届关东高校弓道大赛优胜":

                                        size 20
                                        color "#333333"

                                    text "恭喜我校弓道部成员，希望能够再接再厉勇创佳绩！":

                                        size 17
                                        color "#777777"
                                    
                                    text "2026.09.13":

                                        size 16
                                        color "#888888"

                            text "热门内容":

                                size 18
                                color "#444444"
                                bold True

                            frame:

                                xsize 810
                                ysize 150

                                background "#ffffff"

                                vbox:

                                    xpos 20
                                    ypos 15

                                    spacing 8

                                    hbox:
                                        add "ito_icon":
                                            xsize 30
                                            ysize 30
                                        null width 10
                                        text "今天也要AAO":

                                            size 22
                                            color "#333333"
                                            bold True

                                    text "新生社团应援部招人！需要凑够5个才能提交申请！有意向的请联系本人！！非常感谢":

                                        size 17
                                        color "#666666"

                                    text "2027.01.14":

                                        size 16
                                        color "#888888"

                            frame:

                                xsize 810
                                ysize 150

                                background "#ffffff"

                                vbox:

                                    xpos 20
                                    ypos 15

                                    spacing 8

                                    hbox:
                                        add "gdgd_icon":
                                            xsize 30
                                            ysize 30
                                        null width 10
                                        text "负鼠乐队重度依赖":

                                            size 22
                                            color "#333333"
                                            bold True

                                    text "每日一寻找一起看负鼠乐队的同好(1/1)":

                                        size 17
                                        color "#666666"

                                    text "2027.01.20":

                                        size 16
                                        color "#888888"



                else:

                    # ------------------------------------------
                    # 搜索结果
                    # ------------------------------------------

                    viewport:

                        xpos 0
                        ypos 0

                        xsize 840
                        ysize 555

                        scrollbars "vertical"

                        mousewheel True
                        draggable True

                        vbox:

                            xsize 810

                            xpos 20

                            spacing 15


                            # ==================================================
                            # 搜索关键词
                            # ==================================================

                            text "搜索结果":

                                size 24
                                color "#444444"
                                bold True

                            text "关键词： [forum_search_keyword]":

                                size 16
                                color "#888888"


                            # ==================================================
                            # 在这里根据关键词显示不同内容
                            # ==================================================

                            if forum_search_keyword == "正射必中":

                                $ final = True
                                $ cur_clue = clues[11]
                                $ cur_clue["unlocked"] = True
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10

                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "大赛倒计时7天。今天也在加练":

                                            size 17
                                            color "#666666"

                                        text "2026.09.07":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "大赛倒计时2天，为什么越来越力不从心了...":

                                            size 17
                                            color "#666666"

                                        text "2026.09.11":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "大赛倒计时1天，老师很担心我的状况...但我真的要就这样退赛吗...还是先好好休息吧。":

                                            size 17
                                            color "#666666"

                                        text "2026.09.12":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "昨天做了个奇怪的梦，但也多亏这个梦帮助我克服了心理障碍拿下大赛优胜，我今后也会继续努力的。":

                                            size 17
                                            color "#666666"

                                        text "2026.09.13":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 180

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "今天才知道，上次做的那个奇怪的梦里面的剧情和《颜面球杀人事件》的内容好像啊...不如说那真的是梦吗，也太真实了，\n难不成我是卷进了什么灵异事件...":

                                            size 17
                                            color "#666666"

                                        text "2026.10.17":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "原来之前那个是真实的...我就说霧谷这个姓氏不可能这么常见吧。":

                                            size 17
                                            color "#666666"

                                        text "2026.10.23":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "虽然之前就有体会，但那家伙的性格确实很恶劣啊":

                                            size 17
                                            color "#666666"

                                        text "2026.12.01":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 150

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "那家伙居然会来找我帮忙，但又说只叫我带着这个U盘去livehouse就好，看在她请我门票的份上就勉强帮一下吧":

                                            size 17
                                            color "#666666"

                                        text "2027.01.18":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 150

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "那个叫负鼠的乐队演出真的蛮不错的哎，下次有机会还可以来看一看。不过到最后也不知道她要干什么，希望不会又是什么恶作剧。":

                                            size 17
                                            color "#666666"

                                        text "2027.01.19":

                                            size 16
                                            color "#888888"
                                frame:

                                    xsize 810
                                    ysize 130

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10
                                        hbox:
                                            add "mio_icon"
                                            null width 10
                                            text "正射必中":

                                                size 22
                                                color "#333333"
                                                bold True

                                        text "突然感觉之前不应该帮那家伙的，感觉碰上她自己总是被牵着鼻子走。":

                                            size 17
                                            color "#666666"

                                        text "2027.01.21":

                                            size 16
                                            color "#888888"


                                # 可以继续添加帖子


                            elif forum_search_keyword == "Alice":

                                frame:

                                    xsize 810
                                    ysize 180

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 15

                                        spacing 10

                                        text "Alice":

                                            size 22
                                            color "#333333"
                                            bold True

                                        text "这里放 Alice 相关的论坛内容。":

                                            size 17
                                            color "#666666"


                            else:

                                frame:

                                    xsize 810
                                    ysize 120

                                    background "#ffffff"

                                    vbox:

                                        xpos 20
                                        ypos 20

                                        spacing 10

                                        text "没有找到相关内容":

                                            size 20
                                            color "#555555"

                                        text "请尝试搜索其他关键词。":

                                            size 16
                                            color "#999999"
    textbutton "X":

        xpos 1160
        ypos 50

        action Return("close")                                                
label mari_clue:

    call screen mari_search

    return

screen mari_search():

    modal True

    $ cur_clue = clues[5]
    $ cur_clue["unlocked"] = True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        text "已为您检索到如下信息：":

            xpos 50
            ypos 25
    
        textbutton "M_M的Insta主页":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 100

            action Call("open_mariinfo")
        text "进入insta 分享你的生活":

            size 15

            xpos 110
            ypos 140

        text "https://insta.mari.com":

            size 15

            xpos 110
            ypos 85
    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

label open_mariinfo:

    call screen mari_information

    return

screen mari_information():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        
        frame:
            xsize 850
            ysize 640
            background "#ffffff"
            viewport:

                scrollbars "vertical"

                mousewheel True

                draggable True

                vbox:
                    text "M_M 的个人主页":
                        xpos 100
                        ypos 25
                        size 25
                    add Solid("#dddddd"):
                        xsize 850
                        ysize 2
                        ypos 30
                    add "mari_icon":
                        xpos 30
                        ypos 50
                        xsize 80
                        ysize 80
                    text "Mari.J":
                        xpos 200
                        ypos -25
                        size 25
                    hbox:
                        text "帖子 \n 37":
                            xpos 200
                            ypos -30
                            size 20
                        text "粉丝 \n 2173":
                            xpos 400
                            ypos -30
                            size 20
                        text "关注 \n 10":
                            xpos 600
                            ypos -30
                            size 20
                    text "nothing special nothing to love":
                        xpos 50
                        size 18
                        italic True
                    null height 5
                    add Solid("#dddddd"):
                        xsize 850
                        ysize 2   
                    null height 5
                    hbox:
                        add "mari_icon":

                                xpos 50
                                xsize 30
                                ysize 30
                        text "{b}M_M{/b}": 
                            size 18
                            xpos 75
                    add "mari_2":
                        xpos 200
                    null height 5
                    hbox:
                        xpos 100
                        text "点赞 720":
                            size 18
                        null width 30
                        text "评论 21":
                            size 18
                        null width 30
                        text "转发 3":
                            size 18
                    null height 5
                    text "{b}M_M{/b} 演出很好看 不过今天主唱智哉好像临时有事 安可时候才出现 前面是经纪人小姐救的场":
                        size 18
                        xpos 80
                    text "经纪人小姐也很厉害呢 顺带一提 在开演前yuika给我看了几眼新作 非常有意思 \n 大家可以期待一下 到时候我也会去支持的":
                        size 18
                        xpos 120
                    null height 5
                    text "1月19日":
                        size 16
                        xpos 80
                        color "#666666"
                    null height 5
                    add Solid("#dddddd"):
                        xsize 850
                        ysize 2   
                    null height 5    

                    hbox:
                        add "mari_icon":

                                xpos 50
                                xsize 30
                                ysize 30
                        text "{b}M_M{/b}": 
                            size 18
                            xpos 75
                        text "🎶 负鼠乐队--《点燃心火》":
                            size 16
                            xpos 110
                            color "#666666"
                    add "mari_3":
                        xpos 200
                    null height 5
                    hbox:
                        xpos 100
                        text "点赞 430":
                            size 18
                        null width 30
                        text "评论 15":
                            size 18
                        null width 30
                        text "转发 2":
                            size 18
                    null height 5
                    text "{b}M_M{/b} 期待了很久的live 和yuika一起":
                        size 18
                        xpos 80
                    null height 5
                    text "1月19日":
                        size 16
                        xpos 80
                        color "#666666"
                    null height 5
                    add Solid("#dddddd"):
                        xsize 850
                        ysize 2   
                    null height 5

                    hbox:
                        add "mari_icon":

                                xpos 50
                                xsize 30
                                ysize 30
                        text "{b}M_M{/b}": 
                            size 18
                            xpos 75
                    add "mari_1":
                        xpos 200
                    null height 5
                    hbox:
                        xpos 100
                        text "点赞 520":
                            size 18
                        null width 30
                        text "评论 34":
                            size 18
                        null width 30
                        text "转发 5":
                            size 18
                    null height 5
                    text "{b}M_M{/b} 谢谢你":
                        size 18
                        xpos 80
                    null height 5
                    text "6月29日":
                        size 16
                        xpos 80
                        color "#666666"
                    null height 5
                    add Solid("#dddddd"):
                        xsize 850
                        ysize 2   
                    null height 5  

                    hbox:
                        add "mari_icon":

                                xpos 50
                                xsize 30
                                ysize 30
                        text "{b}M_M{/b}": 
                            size 18
                            xpos 75
                    add "mari_4":
                        xpos 200
                    null height 5
                    hbox:
                        xpos 100
                        text "点赞 243":
                            size 18
                        null width 30
                        text "评论 37":
                            size 18
                        null width 30
                        text "转发 1":
                            size 18
                    null height 5
                    text "{b}M_M{/b} 这本漫画很好看":
                        size 18
                        xpos 80
                    null height 5
                    text "6月26日":
                        size 16
                        xpos 80
                        color "#666666"
                    null height 5
                    add Solid("#dddddd"):
                        xsize 850
                        ysize 2   
                    null height 5
                    
        frame:
            xsize 240
            xpos 850
            ysize 640
            background "#ffffff"

            text "{b}发现更多用户{/b}"
            hbox:
                ypos 40
                add "saita_icon"
                text "琦玉会不会写":
                    size 18
                    ypos 15
                text "14422":
                    size 16
                    ypos 35
                    xpos -100
                    color "#696969"
            null height 10
            hbox:
                ypos 100
                add "kpbl_icon"
                text "水豚饲养员":
                    size 18
                    ypos 15

    textbutton "X":

        xpos 1120
        ypos 50

        action Return()
label open_minainfo:

    call screen mina_information

    return

screen mina_information():

    modal True

    $ cur_clue = clues[9]
    $ cur_clue["unlocked"] = True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        viewport:

            scrollbars "vertical"

            mousewheel True

            draggable True

            vbox:
                # 顶部区域
                fixed:
                    xsize 800
                    ysize 250
                    add "mina_banner":

                        xsize 800
                        ysize 200

                    add "mina_icon":

                        xpos 25
                        ypos 125

                hbox:
                    text "おせっかいさん":

                        size 20

                    null width 475

                    textbutton "关注":

                        background "#008cff"

                        text_color "#ffffff"

                        padding (15,8)


                text "@km0707":

                    size 15

                    color "#666666"


                text """
                想要画出有你在的这个世界
                """:
                    size 18

                text "📅 2025年1月 加入":

                    size 15


                text "37 正在关注     3 关注者":

                    size 15

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                
                null height 5
                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 1月20日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "帮助朋友和妹妹和好了 真是有惊无险 \n 这下愿望清单上的内容又完成一项...太好了":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  2":
                        size 18
                        xpos 250
                    
                    text "点赞  1":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 1月19日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "今天庆祝朋友完全康复 看到她健康真的太好了 \n 虽说她总说我是不是有点过度保护...但我只是不想再看到她受伤了":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  0":
                        size 18
                        xpos 250
                    
                    text "点赞  5":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 11月21日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                add "mina_3":
                    xpos 50
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  2":
                        size 18
                        xpos 250
                    
                    text "点赞  4":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 9月13日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "被朋友拉着一起去看弓道比赛了 明明应该让她好好养伤的 可惜我说不过她\n 不过这里也很让人能静下心来呢 像画室一样":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  0":
                        size 18
                        xpos 250
                    
                    text "点赞  3":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 8月05日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "朋友的伤好的很快 太好了...":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  0":
                        size 18
                        xpos 250
                    
                    text "点赞  1":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 7月20日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "今天去看望了朋友 幸好伤的不是很重 要不然我真的会后悔死......":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  0":
                        size 18
                        xpos 250
                    
                    text "点赞  7":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 7月19日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "朋友出车祸了...都是我的错...如果我放学选择和她一起走的话...":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  0":
                        size 18
                        xpos 250
                    
                    text "点赞  1":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "mina_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "おせっかいさん": 
                        size 18
                        xpos 20
                    
                    text "@km0707 - 6月13日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "决定去尝试一下这个比赛":
                    xpos 50
                    size 22
                
                null height 10
                add "mina_2":
                    xpos 50
                null height 5
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  2":
                        size 18
                        xpos 250
                    
                    text "点赞  6":
                        size 18
                        xpos 450
                null height 5

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5


    textbutton "X":

        xpos 1120
        ypos 50

        action Return()
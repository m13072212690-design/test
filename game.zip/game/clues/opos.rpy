label opos_clue:

    call screen opos_search

    return

screen opos_search():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        text "已为您检索到如下信息：":

            xpos 50
            ypos 25
    
        textbutton "负鼠乐队--主页":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 100

            action Function(open_oposinfo)
        text "No Rock No Life !":

            size 15

            xpos 110
            ypos 140

        text "https://opossum.com":

            size 15

            xpos 110
            ypos 85

        textbutton "吉井 铃香的Tmitter主页":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 190

            action Call("open_suzukainfo")
        text "负鼠乐队经纪人 商务合作请发送至<opossum@smail.com>":

            size 15

            xpos 110
            ypos 230

        text "https://x.suzuka.com":

            size 15

            xpos 110
            ypos 175
    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

init python:
    def open_oposinfo():

        renpy.notify(
                "暂无有效信息"
            )
        return


label open_suzukainfo:

    call screen suzuka_information

    return

screen suzuka_information():

    modal True

    $ cur_clue = clues[6]
    $ cur_clue["unlocked"] = True

    $ cur_clue = clues[8]
    $ cur_clue["unlocked"] = True

    $ cur_clue = clues[7]
    $ cur_clue["unlocked"] = True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        viewport:

            scrollbars "vertical"

            mousewheel True

            draggable True

            vbox:
                # 顶部区域
                fixed:
                    xsize 800
                    ysize 250
                    add "suzuka_banner":

                        xsize 800
                        ysize 200

                    add "suzuka_icon":

                        xpos 25
                        ypos 125

                hbox:
                    text "吉井 铃香-opossum":

                        size 20

                    null width 475

                    textbutton "关注":

                        background "#008cff"

                        text_color "#ffffff"

                        padding (15,8)


                text "@suzuka0412":

                    size 15

                    color "#666666"


                text """
                负鼠乐队经纪人 
                商务合作请发送至<opossum@smail.com>
                """:
                    size 18

                text "📅 2023年6月 加入":

                    size 15


                text "31 正在关注     72938 关注者":

                    size 15

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                
                null height 5

                hbox:
                    add "suzuka_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "吉井 铃香-opossum": 
                        size 18
                        xpos 20
                    
                    text "@suzuka0412 - 1月20日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "|||||||||||||||||||||||||\n负鼠乐队巡演东京场 圆满完成~~~~！！ \n一直以来非常感谢大家的支持 虽然途中有些小插曲 但还是圆满完成了\n从今以后也请继续支持我们 和我们一起点燃心火下去吧！\n|||||||||||||||||||||||||\n#opossum":
                    xpos 50
                    size 22
                
                null height 10
                add "suzuka_1":
                    xpos 50
                null height 5
                hbox:
                    text "转发  135": 
                        size 18
                        xpos 50
                    
                    text "评论  268":
                        size 18
                        xpos 250
                    
                    text "点赞  2310":
                        size 18
                        xpos 450
                null height 5
                text "热门评论":
                    xpos 75
                    color "#ff3c3c"
                    size 18
                null height 5 
                hbox:
                    add "gdgd_icon":
                        xpos 90
                    text "嘎达嘎达":
                        xpos 110
                        size 16
                    text "@egglove":
                        xpos 115
                        size 16
                        color "#666666"
                text "我已经完全是铃香小姐的粉丝了！":
                        xpos 150
                        size 18
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "suzuka_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "吉井 铃香-opossum": 
                        size 18
                        xpos 20
                    
                    text "@suzuka0412 - 1月19日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "失物招领\n这是哪位粉丝落下的 请尽快联系我们！\n#opossum":
                    xpos 50
                    size 22
                
                null height 10
                add "suzuka_3":
                    xpos 50
                null height 5
                hbox:
                    text "转发  53": 
                        size 18
                        xpos 50
                    
                    text "评论  123":
                        size 18
                        xpos 250
                    
                    text "点赞  810":
                        size 18
                        xpos 450
                null height 5
                text "热门评论":
                    xpos 75
                    color "#ff3c3c"
                    size 18
                null height 5 
                hbox:
                    add "mina_icon":
                        xpos 90
                        xsize 30
                        ysize 30
                    textbutton "おせっかいさん":
                        xpos 110
                        ypos -3
                        text_size 16
                        text_color "#1b1a1a"
                        action Call("open_minainfo")

                    text "@km0707":
                        xpos 115
                        size 16
                        color "#666666"
                text "铃香小姐辛苦了！这个是我朋友的 我们明天去livehouse找你们拿！十分感谢":
                        xpos 150
                        size 18
                null height 5
                hbox:
                    text "回复":
                        color "#053eaf"
                        xpos 90
                        size 18 
                    add "suzuka_icon":

                            xpos 100
                            xsize 30
                            ysize 30
                    text "吉井 铃香-opossum": 
                        size 16
                        xpos 110
                text "好哦~ ":
                    xpos 185
                    size 18
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5
                                
                hbox:
                    add "suzuka_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "吉井 铃香-opossum": 
                        size 18
                        xpos 20
                    
                    text "@suzuka0412 - 1月19日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "今天就是正式演出 加油！\n#opossum":
                    xpos 50
                    size 22
                
                null height 10
                add "suzuka_2":
                    xpos 50
                null height 5
                hbox:
                    text "转发  98": 
                        size 18
                        xpos 50
                    
                    text "评论  181":
                        size 18
                        xpos 250
                    
                    text "点赞  2801":
                        size 18
                        xpos 450
                null height 5
                text "热门评论":
                    xpos 75
                    color "#ff3c3c"
                    size 18
                null height 5 
                hbox:
                    add "gdgd_icon":
                        xpos 90
                    text "嘎达嘎达":
                        xpos 110
                        size 16
                    text "@egglove":
                        xpos 115
                        size 16
                        color "#666666"
                text "严肃期待！noa小姐也好可爱！":
                        xpos 150
                        size 18
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

    textbutton "X":

        xpos 1120
        ypos 50

        action Return()


label sari_clue:

    call screen sari_search

    return

screen sari_search():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        text "已为您检索到如下信息：":

            xpos 50
            ypos 25
    
        textbutton "サリ@愿望...的Tmitter主页":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 100

            action Call("open_sariinfo")
        text "喜欢分享自己的生活 \n目前正在和朋友挑战愿望清单":

            size 15

            xpos 110
            ypos 140

        text "https://tmitter.sari.com":

            size 15

            xpos 110
            ypos 85
    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

label open_sariinfo:

    call screen sari_information

    return

screen sari_information():

    modal True

    $ cur_clue = clues[10]
    $ cur_clue["unlocked"] = True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        viewport:

            scrollbars "vertical"

            mousewheel True

            draggable True

            vbox:
                # 顶部区域
                fixed:
                    xsize 800
                    ysize 250
                    add "sari_banner":

                        xsize 800
                        ysize 200

                    add "sari_icon":

                        xpos 25
                        ypos 125

                hbox:
                    text "サリ@愿望清单挑战中":

                        size 20

                    null width 475

                    textbutton "关注":

                        background "#008cff"

                        text_color "#ffffff"

                        padding (15,8)


                text "@sari0109":

                    size 15

                    color "#666666"


                text """
                喜欢分享自己的生活 
                目前正在和朋友挑战愿望清单
                """:
                    size 18

                text "📅 2023年7月 加入":

                    size 15


                text "130 正在关注     176 关注者":

                    size 15

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                
                null height 5
                hbox:
                    add "sari_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "サリ@愿望清单挑战中": 
                        size 18
                        xpos 20
                    
                    text "@sari0109 - 1月20日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "终于找到了我的另一只耳机~":
                    xpos 50
                    size 22
                null height 5
                add "sari_1":
                    xpos 50                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  9":
                        size 18
                        xpos 250
                    
                    text "点赞  36":
                        size 18
                        xpos 450
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5
                hbox:
                    add "sari_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "サリ@愿望清单挑战中": 
                        size 18
                        xpos 20
                    
                    text "@sari0109 - 1月19日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "在livehouse又遇到了之前参加弓道赛的那个短发女生 好想和她交个朋友哦 \n可惜没找到机会和她搭话":
                    xpos 50
                    size 22              
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  3":
                        size 18
                        xpos 250
                    
                    text "点赞  29":
                        size 18
                        xpos 450
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "sari_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "サリ@愿望清单挑战中": 
                        size 18
                        xpos 20
                    
                    text "@sari0109 - 1月18日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "美名邀请我和香织一起去看live 虽说是为了庆祝我完全康复 但还是突然有点紧张...":
                    xpos 50
                    size 22              
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  5":
                        size 18
                        xpos 250
                    
                    text "点赞  12":
                        size 18
                        xpos 450
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "sari_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "サリ@愿望清单挑战中": 
                        size 18
                        xpos 20
                    
                    text "@sari0109 - 10月26日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "美名给我画的！好好看！！！\n清单上又一个愿望完成了~":
                    xpos 50
                    size 22   
                null height 5
                add "sari_2":
                    xpos 50           
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  15":
                        size 18
                        xpos 250
                    
                    text "点赞  92":
                        size 18
                        xpos 450
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "sari_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "サリ@愿望清单挑战中": 
                        size 18
                        xpos 20
                    
                    text "@sari0109 - 9月13日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "去看了关东高校弓道大赛~大家都好帅气！尤其是樱之丘高校的那个短发女生！！ \n看得我也有点想去学了 不过被美名教训说等我伤好了再想这些":
                    xpos 50
                    size 22 
                null height 5
                add "sari_3":
                    xpos 50           
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  11":
                        size 18
                        xpos 250
                    
                    text "点赞  23":
                        size 18
                        xpos 450
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5

                hbox:
                    add "sari_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "サリ@愿望清单挑战中": 
                        size 18
                        xpos 20
                    
                    text "@sari0109 - 9月13日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "收到大家的关心了！我没什么大事！！大家放心吧❤":
                    xpos 50
                    size 22 
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  42":
                        size 18
                        xpos 250
                    
                    text "点赞  87":
                        size 18
                        xpos 450
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 5                

    textbutton "X":

        xpos 1120
        ypos 50

        action Return()
label traffic_clue:

    call screen traffic_search

    return

screen traffic_search():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        text "已为您检索到如下信息：":

            xpos 50
            ypos 25
    
        textbutton "东京市XX区一学校附近的十字路口发生一起车祸 致1伤":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 100

            action Call("open_trafficinfo")
        text "2026年7月20日":

            size 15

            xpos 110
            ypos 140

        text "https://NKK.news.com":

            size 15

            xpos 110
            ypos 85
    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

label open_trafficinfo:

    call screen traffic_information

    return

screen traffic_information():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        viewport:

            scrollbars "vertical"

            mousewheel True

            draggable True


            vbox:
                hbox:
                    text "{b}NKK{/b}":
                        size 30
                        xpos 50
                        ypos 25
                        color "#ff0000"
                    null width 75
                    text "news":
                        size 25
                        ypos 25
                        color "#ff0000"
                    null width 150
                    text "东京日报":
                        size 35
                        ypos 25
                null height 30
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 30
                text "{b}东京市XX区一学校附近的十字路口发生一起车祸 致1伤{/b}":
                    xpos 100
                    size 25
                null height 5
                text "编辑：Cktkmonocho  2026年7月20日":
                    size 16
                    color "#666666"
                    xpos 250
                null height 20
                text "昨日（2026年7月19日）傍晚，在东京市XX区一学校附近的十字路口发生一起车祸。":
                    xpos 50
                    size 22
                text "伤者是该校的一名高二学生，名叫秋野沙理，在放学途中遭遇了这起事故。":
                    xpos 20
                    size 22
                text "受害者腿部受伤，目前正在修养，状态良好，没有危及生命。最终该生家长与司机也":
                    xpos 50
                    size 22
                text "达成了赔偿和解。":
                    xpos 20
                    size 22
                add "traffic":
                    xpos 100
                text "图上为事故发生地点":
                    xpos 200
                    size 16
                    color "#666666"
                text "在此我们呼吁各位司机，在通过学校等人流较大的区域时，一定要小心谨慎，避免":
                    xpos 50
                    size 22
                text "发生车祸。道路千万条，安全第一条！":
                    xpos 20
                    size 22


    textbutton "X":

        xpos 1120
        ypos 50

        action Return()
label yuika_clue:

    call screen yuika_search

    return

screen yuika_search():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        text "已为您检索到如下信息：":

            xpos 50
            ypos 25
    
        textbutton "小山内 唯香的Tmitter主页":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 100

            action Call("open_yuikainfo")
        text "商务咨询请发送到<yuika_osanai@smail.com>":

            size 15

            xpos 110
            ypos 140

        text "https://tmitter.yuika.com":

            size 15

            xpos 110
            ypos 85
    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

label open_yuikainfo:

    call screen yuika_information

    return

screen yuika_information():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        viewport:

            scrollbars "vertical"

            mousewheel True

            draggable True


            vbox:
                # 顶部区域
                fixed:
                    xsize 800
                    ysize 250
                    add "yuika_banner":

                        xsize 800
                        ysize 200

                    add "yuika_icon":

                        xpos 25
                        ypos 125

                hbox:
                    text "小山内唯香@NFB_offical":

                        size 20

                    null width 475

                    textbutton "关注":

                        background "#008cff"

                        text_color "#ffffff"

                        padding (15,8)


                text "@yuika0217":

                    size 15

                    color "#666666"


                text """
                商务咨询请发送到<yuika_osanai@smail.com>
                作家 编剧 代表作《颜面球杀人事件》
                """:
                    size 18

                text "📅 2021年8月 加入":

                    size 15


                text "261 正在关注     59238 关注者":

                    size 15

                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                
                null height 5
            #下面都是帖子 帖子1：
                hbox:
                    add "yuika_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "小山内唯香@NFB_offical": 
                        size 18
                        xpos 20
                    
                    text "@yuika0217 - 1月21日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "糟糕...好像搞砸了什么...":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  0": 
                        size 18
                        xpos 50
                    
                    text "评论  12":
                        size 18
                        xpos 250
                    
                    text "点赞  34":
                        size 18
                        xpos 450
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2

                #帖子2：
                null height 5
                hbox:
                    add "yuika_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "小山内唯香@NFB_offical": 
                        size 18
                        xpos 20
                    
                    text "@yuika0217 - 1月19日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "忙里偷闲一下~ ^-^":
                    xpos 50
                    size 22
                null height 5
                add "yuika_1":
                    xpos 50
                
                null height 10
                hbox:
                    text "转发  13": 
                        size 18
                        xpos 50
                    
                    text "评论  51":
                        size 18
                        xpos 250
                    
                    text "点赞  128":
                        size 18
                        xpos 450
                null height 5 
                text "热门评论":
                    xpos 75
                    color "#ff3c3c"
                    size 18
                null height 5 
                hbox:
                    add "jam_icon":
                        xpos 90
                    text "nothing spejam":
                        xpos 110
                        size 16
                    text "@jam6311":
                        xpos 115
                        size 16
                        color "#666666"
                text "看起来好好喝！":
                        xpos 150
                        size 18
                null height 5
                hbox:
                    text "回复":
                        color "#053eaf"
                        xpos 90
                        size 18 
                    add "yuika_icon":

                            xpos 100
                            xsize 30
                            ysize 30
                    text "小山内唯香@NFB_offical": 
                        size 16
                        xpos 110
                text "是mari的推荐！真的很好喝":
                    xpos 185
                    size 18
                null height 5
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                #帖子3：
                null height 5
                hbox:
                    add "yuika_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "小山内唯香@NFB_offical": 
                        size 18
                        xpos 20
                    
                    text "@yuika0217 - 1月18日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "赶稿成功！！safe~~~~":
                    xpos 50
                    size 22
                
                null height 10
                hbox:
                    text "转发  5": 
                        size 18
                        xpos 50
                    
                    text "评论  37":
                        size 18
                        xpos 250
                    
                    text "点赞  368":
                        size 18
                        xpos 450
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                #帖子4
                null height 5
                hbox:
                    add "yuika_icon":

                            xpos 10
                            xsize 30
                            ysize 30
                    text "小山内唯香@NFB_offical": 
                        size 18
                        xpos 20
                    
                    text "@yuika0217 - 2026年6月28日":
                        size 18
                        color "#666666"
                        xpos 30

                null height 5
                text "这次该我直视自己的心意了......":
                    xpos 50
                    size 22
                null height 5
                add "yuika_2":
                    xpos 50
                
                null height 10
                hbox:
                    text "转发  15": 
                        size 18
                        xpos 50
                    
                    text "评论  102":
                        size 18
                        xpos 250
                    
                    text "点赞  527":
                        size 18
                        xpos 450
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2


    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()
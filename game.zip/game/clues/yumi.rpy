label yumi_clue:

    call screen yumi_search

    return

screen yumi_search():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        text "已为您检索到如下信息：":

            xpos 50
            ypos 25
    
        textbutton "第17届关东高校弓道大赛":

            text_color "#0066cc"
            text_size 30

            xpos 100
            ypos 100

            action Call("open_yumiinfo")
        text "2026年9月13日":

            size 15

            xpos 110
            ypos 140

        text "https://KandouHighschoolKyudo.com":

            size 15

            xpos 110
            ypos 85
    
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

label open_yumiinfo:

    $ nishihara = True
    call screen yumi_information

    return

screen yumi_information():

    modal True

    frame:

        xsize 1100
        ysize 650

        xalign 0.5
        yalign 0.5

        viewport:

            scrollbars "vertical"

            mousewheel True

            draggable True

            vbox:
                hbox:
                    text "{b}关东高校弓道联盟{/b}":
                        size 30
                        xpos 50
                        ypos 25
                        color "#4c3c0b"
                    null width 15
                    text "Kandou Highschool Kyudo Federation":
                        size 20
                        ypos 35
                        xpos 50
                null height 30
                add Solid("#dddddd"):

                    xsize 850
                    ysize 2
                null height 30
                text "{b}第17届关东高校弓道大赛结果公示{/b}":
                    xpos 100
                    size 25
                null height 5
                text "2026年9月13日":
                    size 16
                    color "#666666"
                    xpos 250
                null height 20
                text "今日（2026年9月13日）第17届关东高校弓道大赛圆满结束。":
                    xpos 50
                    size 22
                add "yumi_2":
                    xpos 100     
                text "图:赛时评委席":
                    xpos 250
                    size 16
                    color "#666666"           
                text "关东地区多所高校经过激烈的角逐，最终取得优胜的是樱之丘高校。":
                    xpos 50
                    size 22
                text "其中来自樱之丘高校的西原 紬拿下了至关重要的一箭，奠定了团队的胜局。":
                    xpos 20
                    size 22
                add "yumi_1":
                    xpos 100     
                text "图:赛时的西原同学":
                    xpos 250
                    size 16
                    color "#666666" 
                text "赛后采访时面对记者提问西原同学今天的发挥时，她也只是谦虚的回答说，":
                    xpos 50
                    size 22
                text "自己只是坚信着正射必中的准则而已，准心对准好目标之后就不要再多想了。同时并\n表示自己还有很多不足，需要继续精进。随后将在傍晚进行颁奖典礼，期待各高校明年的表现。":
                    xpos 20
                    size 22                               



    textbutton "X":

        xpos 1120
        ypos 50

        action Return()
screen computer_desktop():


    # 邮件图标

    imagebutton:

        idle "email"

        xpos 50
        ypos 50

        action Call("open_email")
    text "邮箱":

        xpos 50
        ypos 100



    # Chappy图标

    imagebutton:

        idle "chappy"

        xpos 50
        ypos 150


        action Call("open_chappy")
    text "chappy...?":

        xpos 50
        ypos 210

    #line 图标
    imagebutton:

        idle "line"

        xpos 50
        ypos 250


        action Call("open_line")
    text "line":

        xpos 55
        ypos 310

    #搜查记录 图标
    imagebutton:

        idle "search"

        xpos 50
        ypos 360


        action Call("open_search")
    text "搜查记录":

        xpos 55
        ypos 420

## 游戏内子屏幕
## 1.点击邮件图标打开内容
screen email():


    imagebutton:

        idle "mail_icon"

        xpos 50
        ypos 50

        action [Hide("email"), Call("open_email")]

    text "点击查看":

        xpos 50
        ypos 100

label open_email:

    call screen email_client

    return

screen email_client():

    modal True

    frame:

        xsize 1100
        ysize 650

        xpos 90
        ypos 35


        background "#eeeeee"


        hbox:

            # 左侧邮件列表

            frame:

                xsize 350
                ysize 640

                background "#e5e5e5"


                vbox:

                    frame:
                        xsize 340
                        ysize 50
                        background "#dcdcdc"
                        text "           收件箱":
                            size 30
                            color "#0091ff"


                    for mail in emails:


                        textbutton mail["title"]:

                            action SetVariable(
                                "current_email",
                                mail["id"]
                            )


            # 右侧邮件内容

            frame:

                xsize 730
                ysize 640


                background "#eeeeee"


                use email_content
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

screen email_content():


    $ mail = emails[current_email]

    if mail["id"] == 1 :
        $ cur_clue = clues[4]
        $ cur_clue["unlocked"] = True


    vbox:


        spacing 15

        frame:
            xsize 650
            ysize 40

            text "[mail['title']]"

            background "#ffffff"

        null height 5

        text "[mail['sender']] <[mail['mail']]>"


        text "[mail['date']]":
            size 15

        textbutton "回复":
            background "#0786c1"
            text_color "#ffffff"
            xpos 325
            if mail["id"] == 0 and nishihara == True:

                action Call("reply_answer")
            else:
                action Function(nonreply)
        frame:
            xsize 700
            ysize 430

            text mail["content"]

            background "#ffffff"



init python:


    def nonreply():

        renpy.notify("当前无法回复")
## 游戏内子屏幕
## 1.点击邮件图标打开内容
screen email():


    imagebutton:

        idle "mail_icon"

        xpos 50
        ypos 50

        action [Hide("email"), Call("open_email")]

    text "点击查看":

        xpos 50
        ypos 100

label open_email:

    call screen email_client

    return

screen email_client():

    modal True

    frame:

        xsize 1100
        ysize 650

        xpos 90
        ypos 35


        background "#eeeeee"


        hbox:

            # 左侧邮件列表

            frame:

                xsize 350
                ysize 650

                background "#dddddd"


                vbox:


                    text "收件箱"


                    for mail in emails:


                        textbutton mail["title"]:

                            action SetVariable(
                                "current_email",
                                mail["id"]
                            )



            # 右侧邮件内容

            frame:

                xsize 750
                ysize 650


                background "#ffffff"


                use email_content
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

screen email_content():


    $ mail = emails[current_email]

    if mail["id"] == 1 :
        $ cur_clue = clues[4]
        $ cur_clue["unlocked"] = True


    vbox:


        spacing 15


        text "发件人: [mail['sender']]"

        text "邮箱: [mail['mail']]"

        text "标题: [mail['title']]"


        text "日期: [mail['date']]"

        textbutton "回复":
            background "#0786c1"
            text_color "#ffffff"
            xpos 325
            if mail["id"] == 0:

                action Call("reply_answer")
            else:
                action Function(nonreply)

        text mail["content"]


init python:


    def nonreply():

        renpy.notify("当前无法回复")
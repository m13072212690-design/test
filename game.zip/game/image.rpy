# image.rpy

image bg pc = im.Scale("images/pcbackground.jpg",1280,720)

image room = im.Scale("images/room.png",1280,720)

image mail_icon = im.Scale("images/mail_icon.png",60,60)

image email = im.Scale("images/email.png",60,60)

image chappy = im.Scale("images/doubao.png",60,60)

image chappy_logo = im.Scale("images/doubao_bannner.png",600,300)

image line = im.Scale("images/line_icon.png",60,60)

image search = im.Scale("images/search.png",60,60)

image yuika_banner = im.Scale("images/yuika_banner.jpg",240,120)

image yuika_icon = im.Scale("images/yuika_icon.png",120,120)

image yuika_1 = im.Scale("images/yuika_photo1.jpg",300,400)

image yuika_2 = im.Scale("images/yuika_photo2.jpg",400,300)

image jam_icon = im.Scale("images/jam_icon.png",30,30)

image mari_icon = "images/mari_icon.png"

image mari_1 = im.Scale("images/mari_photo1.jpg",400,300)

image mari_2 = im.Scale("images/mari_photo2.jpg",300,400)

image mari_3 = im.Scale("images/mari_photo3.jpg",300,400)

image mari_4 = im.Scale("images/mari_photo4.jpg",300,400)

image suzuka_banner = im.Scale("images/suzuka_banner.jpg",240,120)

image suzuka_icon = im.Scale("images/suzuka_icon.png",120,120)

image suzuka_1 = im.Scale("images/suzuka_photo1.jpg",480,270)

image suzuka_2 = im.Scale("images/suzuka_photo2.jpg",384,512)

image suzuka_3 = im.Scale("images/suzuka_photo3.jpg",300,300)

image gdgd_icon = im.Scale("images/gdgd_icon.png",30,30)

image mina_banner = im.Scale("images/mina_banner.jpg",240,120)

image mina_icon = im.Scale("images/mina_icon.png",120,120)

image mina_1 = im.Scale("images/mina_photo1.jpg",480,270)

image mina_2 = im.Scale("images/mina_photo2.jpg",400,300)

image mina_3 = im.Scale("images/mina_photo3.jpg",300,300)

image traffic = im.Scale("images/traffic.jpg",400,300)

image sari_banner = im.Scale("images/mina_photo1.jpg",240,120)

image sari_icon = im.Scale("images/sari_icon.png",120,120)

image sari_1 = im.Scale("images/sari_photo1.jpg",300,400)

image sari_2 = im.Scale("images/sari_photo2.jpg",400,300)

image sari_3 = im.Scale("images/sari_photo3.jpg",400,300)

image yumi_1 = im.Scale("images/yumi_photo1.jpg",480,270)

image yumi_2 = im.Scale("images/yumi_photo2.jpg",480,270)

image saki_icon = im.Scale("images/saki_icon.png",60,60)

image rei_icon = im.Scale("images/rei_icon.png",60,60)

image ito_icon = im.Scale("images/ito_icon.png",60,60)

image mio_icon = im.Scale("images/mio_icon.png",30,30)

image skgm_icon = im.Scale("images/skgm_icon.png",60,60)

image saita_icon = im.Scale("images/saita.png",60,60)

image kpbl_icon = im.Scale("images/kpbl.png",60,60)

image rei_normal = im.Scale("images/rei.png",700,1400)

image rei_cur = im.Scale("images/rei_cur.png",700,1400)

image rei_happy = im.Scale("images/rei_happy.png",700,1400)

image rei_smile = im.Scale("images/rei_smile.png",700,1400)

image saki_normal = im.Scale("images/saki.png",700,1400)

image saki_cur = im.Scale("images/saki_cur.png",700,1400)

image saki_puz = im.Scale("images/saki_puzz.png",700,1400)

image saki_shock = im.Scale("images/saki_shock.png",700,1400)

image saki_shy = im.Scale("images/saki_shy.png",700,1400)

image saki_wdl = im.Scale("images/saki_wdl.png",700,1400)
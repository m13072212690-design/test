# ============================================================
# 聊天软件 Demo
# 剧情节点式聊天系统
# ============================================================


# ============================================================
# 1. 玩家资料
# ============================================================

default player = {
    "name": "我",
    "avatar": "saki_icon",
}


# ============================================================
# 2. 联系人资料
# ============================================================

default contacts = {

    "rei": {
        "name": "霧谷 玲衣",
        "avatar": "rei_icon",
        "unlocked": True,
        "unread": 0,
    },

    "inaba": {
        "name": "稻葉 京花",
        "avatar": "ito_icon",
        "unlocked": True,
        "unread": 0,
    },

    "mari": {
        "name": "坂上前辈",
        "avatar": "skgm_icon",
        "unlocked": True,
        "unread": 0,
    },

}


# ============================================================
# 3. 当前正在查看的联系人
# ============================================================

default active_contact = "rei"


# ============================================================
# 4. 输入框中的文字
#
# 目前你的系统使用“剧情选项”而不是自由输入，
# 所以这个变量暂时保留。
# ============================================================

default chat_input = ""


# ============================================================
# 5. 聊天记录
#
# 非常重要：
#
# 每个联系人都有独立的聊天记录。
#
# 切换联系人不会清除这里的数据。
# ============================================================

default messages = {

    "rei": [

        {
            "sender": "rei",
            "text": "小咲可以看看搜查记录",
        },

        {
            "sender": "rei",
            "text": "一些搜索到的有用信息都会记录在上面",
        },

        {
            "sender": "rei",
            "text": "以及，如果觉得搜查的差不多了",
        },

        {
            "sender": "rei",
            "text": "可以对唯香的邮件进行回复来输入你觉得偷走原稿的人是谁",
        },

        {
            "sender": "rei",
            "text": "哦对了还有，",
        },

        {
            "sender": "rei",
            "text": "输入好搜查内容后不要忘了点击回车",
        },

    ],
    "inaba":[],

    "mari": [

        {
            "sender": "mari",
            "text": "望月编辑，最近有一本新书需要你来进行一下对接",
        },       
        {
            "sender": "mari",
            "text": "明天你有空的话记得来找我一下",
        },
    ],

}


# ============================================================
# 6. 网页解锁变量
#
# 当玩家打开西原紬相关网页之后：
#
# $ nishihara = True
#
# 即可解锁京花的这段聊天剧情。
# ============================================================



# ============================================================
# 7. 每个联系人的独立剧情状态
#
# 这里是这次修改的核心。
#
# 不再使用一个全局的：
#
# current_chat_event
# current_chat_node
#
# 而是让每个联系人拥有自己的剧情状态。
#
# 例如：
#
# 京花：
#     event = inaba_nishihara
#     node = node_2
#
# 玲衣：
#     event = rei_xxx
#     node = node_1
#
# Mari：
#     event = None
#
# ============================================================

default chat_states = {

    "rei": {
        "event": None,
        "node": None,
        "selected_option": "",
    },

    "inaba": {
        "event": None,
        "node": None,
        "selected_option": "",
    },

    "mari": {
        "event": None,
        "node": None,
        "selected_option": "",
    },

}


# ============================================================
# 8. 聊天剧情是否已经完成
#
# 每一个剧情单独保存。
# ============================================================

default chat_event_completed = {

    "inaba_nishihara": False,

    # 以后可以继续添加：
    #
    # "rei_xxx": False,
    # "rei_xxx_2": False,
    #

}


# ============================================================
# 9. 聊天剧情节点数据
# ============================================================

init python:

    chat_events = {

        # ====================================================
        # 京花 —— 西原紬剧情
        # ====================================================

        "inaba_nishihara": {

            "contact": "inaba",

            "start": "node_1",

            "nodes": {

                # =================================================
                # 节点 1
                # =================================================

                "node_1": {

                    "options": [

                        {

                            "text": "京花 你现在方便吗 想问问你认不认识你们学校一个叫西原紬的女生",

                            "replies": [

                                "西原...？是那个弓道部的对吧",

                                "她在我们学校还蛮有名的",

                                "好像是因为之前她们弓道部比赛获奖了",

                                "我每次放学都能看到不少人围着看她们社团训练",

                                "有一次我也凑过去看了一眼",

                                "不得不说 确实很帅气",

                                "啊啊扯远了",

                                "小咲你有什么事要找她吗？",

                            ],

                            "next": "node_2",

                        },

                    ],

                },


                # =================================================
                # 节点 2
                # =================================================

                "node_2": {

                    "options": [

                        {

                            "text": "嗯...有些工作相关的事情...你知不知道她最近这几天都做过什么吗？",

                            "replies": [

                                "最近吗...我是不太清楚哎",

                                "不过我可以把我们学校论坛的网址发你",

                                "sakuranooka.forum 搜索这个就可以了",

                                "我之前好像刷到过她在上面发东西",

                                "可以去那里看看",

                                "不过我有点记不清她的ID了",

                                "好像是四个字",

                                "是个和弓道相关的格言来着",

                            ],

                            "next": "node_3",

                        },

                    ],

                },


                # =================================================
                # 节点 3
                #
                # 这里京花发送网页链接
                # =================================================

                "node_3": {
                    "options": [

                        {
                            "text": "嗯嗯好 麻烦京花了",

                            "replies": [
                                "没事的！小咲之前帮了我这么多",
                                "这是我应该做的",
                                "工作要加油啊！",
                            ],

                            "next": None,

                        },

                    ],

                },


            },

        },

    }


# ============================================================
# 10. 获取当前联系人对应的剧情状态
# ============================================================

init python:

    def get_chat_state(contact_id=None):

        if contact_id is None:
            contact_id = store.active_contact

        return store.chat_states[contact_id]


# ============================================================
# 11. 开始一段聊天剧情
# ============================================================

init python:

    def start_chat_event(event_id):

        event = chat_events[event_id]

        contact_id = event["contact"]

        state = store.chat_states[contact_id]

        state["event"] = event_id
        state["node"] = event["start"]
        state["selected_option"] = ""

        store.chat_input = ""

        renpy.restart_interaction()


# ============================================================
# 12. 选择聊天选项
# ============================================================

init python:

    def select_chat_option(text):

        contact_id = store.active_contact

        state = store.chat_states[contact_id]

        state["selected_option"] = text

        store.chat_input = text

        renpy.restart_interaction()


# ============================================================
# 13. 发送剧情消息
# ============================================================
default pending_replies = []
default pending_reply_contact = None
default reply_sending = False

init python:

    def send_next_reply():

        # ------------------------------------------------
        # 没有正在发送
        # ------------------------------------------------

        if not store.reply_sending:
            return


        # ------------------------------------------------
        # 已经没有剩余消息
        # ------------------------------------------------

        if len(store.pending_replies) == 0:

            store.reply_sending = False

            store.pending_reply_contact = None

            renpy.restart_interaction()

            return


        # ------------------------------------------------
        # 取出下一条消息
        # ------------------------------------------------

        reply = store.pending_replies.pop(0)

        contact_id = store.pending_reply_contact


        # ------------------------------------------------
        # 添加消息
        # ------------------------------------------------

        store.messages[contact_id].append({

            "sender": contact_id,

            "text": reply,

        })


        # ------------------------------------------------
        # 刷新界面
        # ------------------------------------------------

        renpy.restart_interaction()

init python:

    def send_chat_option():

        contact_id = store.active_contact

        state = store.chat_states[contact_id]

        current_chat_event = state["event"]

        current_chat_node = state["node"]

        selected_chat_option = state["selected_option"]


        # ------------------------------------------------
        # 检查
        # ------------------------------------------------

        if selected_chat_option.strip() == "":
            return

        if current_chat_event is None:
            return

        if current_chat_node is None:
            return


        # ------------------------------------------------
        # 获取当前剧情
        # ------------------------------------------------

        event = chat_events[current_chat_event]

        node = event["nodes"][current_chat_node]


        # ------------------------------------------------
        # 找到玩家选择的选项
        # ------------------------------------------------

        selected_option = None

        for option in node["options"]:

            if option["text"] == selected_chat_option:

                selected_option = option

                break


        if selected_option is None:
            return


        # ------------------------------------------------
        # 添加玩家消息
        # ------------------------------------------------

        store.messages[contact_id].append({

            "sender": "me",

            "text": selected_chat_option,

        })


        # ------------------------------------------------
        # 保存 NPC 回复
        # ------------------------------------------------

        store.pending_replies = list(
            selected_option["replies"]
        )

        store.pending_reply_contact = contact_id

        store.reply_sending = True


        # ------------------------------------------------
        # 推进剧情
        # ------------------------------------------------

        next_node = selected_option["next"]


        if next_node is None:

            store.chat_event_completed[current_chat_event] = True

            state["node"] = None

        else:

            state["node"] = next_node


        # ------------------------------------------------
        # 清空当前选择
        # ------------------------------------------------

        state["selected_option"] = ""

        store.chat_input = ""


        # ------------------------------------------------
        # 刷新界面
        # ------------------------------------------------

        renpy.restart_interaction()


# ============================================================
# 14. 左侧联系人列表
# ============================================================

screen contact_list():

    vbox:

        spacing 2

        for cid, contact in contacts.items():

            if contact["unlocked"]:

                button:

                    xsize 330

                    ysize 90

                    background "#f5f5f5"

                    hover_background "#e5e5e5"


                    # =================================================
                    # 点击联系人
                    #
                    # 注意：
                    #
                    # 这里只切换 active_contact。
                    #
                    # 不删除 messages。
                    #
                    # 不删除 chat_states。
                    #
                    # 所以之前的聊天记录和剧情进度都会保留。
                    # =================================================

                    action Function(switch_contact, cid)


                    hbox:

                        spacing 15

                        xalign 0.0

                        yalign 0.5


                        # -----------------------------------------
                        # 联系人头像
                        # -----------------------------------------

                        add contact["avatar"]:

                            xsize 60

                            ysize 60


                        # -----------------------------------------
                        # 名字 + 最近消息
                        # -----------------------------------------

                        vbox:

                            spacing 3

                            xalign 0.0

                            yalign 0.5


                            text contact["name"]:

                                size 21

                                color "#222222"


                            if len(messages[cid]) > 0:

                                text messages[cid][-1]["text"]:

                                    size 14

                                    color "#888888"

                                    xmaximum 180


                        # -----------------------------------------
                        # 未读消息
                        # -----------------------------------------

                        if contact["unread"] > 0:

                            frame:

                                background "#ff3b30"

                                xsize 25

                                ysize 25

                                xalign 1.0

                                yalign 0.5


                                text str(contact["unread"]):

                                    size 14

                                    color "#ffffff"

                                    xalign 0.5

                                    yalign 0.5

init python:

    def switch_contact(cid):

        store.active_contact = cid

        store.contacts[cid]["unread"] = 0

        store.chat_input = ""

        # ------------------------------------------------
        # 如果是京花
        # ------------------------------------------------

        if cid == "inaba":

            state = store.chat_states["inaba"]

            # 已经解锁西原剧情
            if store.nishihara:

                # 剧情还没有完成，并且还没有开始
                if (
                    state["event"] is None
                    and
                    not store.chat_event_completed["inaba_nishihara"]
                ):

                    state["event"] = "inaba_nishihara"

                    state["node"] = chat_events["inaba_nishihara"]["start"]

                    state["selected_option"] = ""


        renpy.restart_interaction()

# ============================================================
# 15. 单条聊天消息
# ============================================================

screen chat_message(message):


    # ========================================================
    # 玩家消息
    # ========================================================

    if message["sender"] == "me":

        hbox:

            xalign 1.0

            spacing 10


            frame:

                background "#95ec69"

                padding (18, 12)

                xmaximum 500


                text message["text"]:

                    size 18

                    color "#000000"


            add player["avatar"]:

                xsize 50

                ysize 50


    # ========================================================
    # 对方消息
    # ========================================================

    else:

        hbox:

            xalign 0.0

            spacing 10


            add contacts[active_contact]["avatar"]:

                xsize 50

                ysize 50


            frame:

                background "#ffffff"

                padding (18, 12)

                xmaximum 500


                text message["text"]:

                    size 18

                    color "#222222"


# ============================================================
# 16. 剧情选项窗口
# ============================================================

screen chat_options():

    modal True


    # ========================================================
    # 半透明背景
    # ========================================================

    add "#00000066"


    frame:

        xsize 640

        ysize 300

        xalign 0.5

        yalign 0.5

        background "#ffffff"

        padding (25, 25)


        vbox:

            spacing 15

            xfill True


            text "选择要发送的消息":

                size 22

                color "#222222"


            # =================================================
            # 当前联系人对应的剧情
            # =================================================

            $ state = chat_states[active_contact]

            if state["event"] is not None:

                if state["node"] is not None:

                    $ event = chat_events[state["event"]]

                    $ node = event["nodes"][state["node"]]


                    for option in node["options"]:

                        textbutton option["text"]:

                            xfill True

                            ysize 60

                            background "#f5f5f5"

                            hover_background "#e5e5e5"

                            text_size 18

                            text_color "#222222"


                            action [

                                Function(
                                    select_chat_option,
                                    option["text"]
                                ),

                                Hide("chat_options"),

                            ]


            textbutton "取消":

                xalign 1.0

                text_size 16

                action Hide("chat_options")


# ============================================================
# 17. 输入区域
# ============================================================

screen chat_input_area():

    $ state = chat_states[active_contact]


    hbox:

        spacing 10

        xfill True

        yalign 0.5


        # ====================================================
        # 输入框
        #
        # 当前版本仍然使用“剧情选项”。
        # 点击后打开 chat_options。
        # ====================================================

        button:

            xsize 600

            ysize 70

            background "#ffffff"

            hover_background "#fafafa"


            action Show("chat_options")


            if state["selected_option"] != "":

                text state["selected_option"]:

                    size 18

                    color "#222222"

                    xalign 0.0

                    yalign 0.5

                    xmaximum 560

            else:

                text "点击选择要发送的消息":

                    size 18

                    color "#999999"

                    xalign 0.0

                    yalign 0.5


        # ====================================================
        # 发送按钮
        # ====================================================

        textbutton "发送":

            xsize 100

            ysize 55

            yalign 0.5

            text_size 20

            background "#07c160"

            hover_background "#06ad56"

            text_color "#ffffff"


            # -----------------------------------------------
            # 当前有选项并且剧情正在进行
            # -----------------------------------------------

            if state["selected_option"] != "" and state["node"] is not None:

                action Function(send_chat_option)

            else:

                sensitive False


# ============================================================
# 18. 聊天主窗口
# ============================================================

screen chat_window():

    if reply_sending:

        timer 1.0 action Function(send_next_reply) repeat True

    frame:

        xsize 740

        ysize 640

        background "#f5f5f5"


        vbox:

            spacing 0


            # =================================================
            # 顶部标题栏
            # =================================================

            frame:

                xsize 740

                ysize 70

                background "#ededed"


                hbox:

                    spacing 15

                    xalign 0.0

                    yalign 0.5


                    add contacts[active_contact]["avatar"]:

                        xsize 45

                        ysize 45


                    text contacts[active_contact]["name"]:

                        size 24

                        color "#222222"


            # =================================================
            # 聊天记录
            # =================================================

            viewport:

                xsize 740

                ysize 440

                draggable True

                mousewheel True

                scrollbars "vertical"

                yinitial 1.0


                frame:

                    xfill True

                    padding (30, 20)

                    background None


                    vbox:

                        spacing 15

                        xfill True


                        # =================================================
                        # 显示当前联系人自己的历史聊天记录
                        #
                        # 这里非常重要：
                        #
                        # 切换联系人不会删除 messages，
                        # 所以切回来以后这里会重新显示原来的内容。
                        # =================================================

                        for message in messages[active_contact]:

                            use chat_message(message)
            

            # =================================================
            # 底部输入区域
            # =================================================

            frame:

                xsize 740

                ysize 130

                background "#f5f5f5"

                padding (20, 20)


                # =================================================
                # 京花
                # =================================================

                if active_contact == "inaba":

                    $ state = chat_states["inaba"]

                    if nishihara:

                        if not chat_event_completed["inaba_nishihara"]:

                            use chat_input_area

                        else:

                            text "暂时没有什么想说的。":

                                size 18

                                color "#999999"

                                xalign 0.5

                                yalign 0.5

                    else:

                        text "暂时没有什么想说的。":

                            size 18

                            color "#999999"

                            xalign 0.5

                            yalign 0.5


                # =================================================
                # 玲衣
                #
                # 目前没有添加剧情。
                #
                # 以后添加剧情时，只需要在这里增加判断。
                # =================================================

                elif active_contact == "rei":

                    $ state = chat_states["rei"]


                    if state["event"] is not None:

                        use chat_input_area

                    else:

                        text "暂时没有什么想说的。":

                            size 18

                            color "#999999"

                            xalign 0.5

                            yalign 0.5


                # =================================================
                # Mari
                #
                # Mari没有剧情。
                #
                # 但是 messages["mari"] 中的历史记录仍然会显示。
                # =================================================

                elif active_contact == "mari":

                    text "暂时没有什么想说的。":

                        size 18

                        color "#999999"

                        xalign 0.5

                        yalign 0.5


# ============================================================
# 19. 整个聊天软件
# ============================================================

screen chat_app():

    modal True


    frame:

        xsize 1100

        ysize 650

        xalign 0.5

        yalign 0.5

        background "#ffffff"


        hbox:

            spacing 0


            # =================================================
            # 左侧联系人
            # =================================================

            frame:

                xsize 350

                ysize 640

                background "#f7f7f7"


                vbox:

                    spacing 0


                    # -----------------------------------------
                    # 左侧顶部
                    # -----------------------------------------

                    frame:

                        xsize 350

                        ysize 70

                        background "#ededed"


                        text "联系人":

                            size 26

                            color "#222222"

                            xalign 0.1

                            yalign 0.5


                    # -----------------------------------------
                    # 联系人
                    # -----------------------------------------

                    viewport:

                        xsize 350

                        ysize 640

                        mousewheel True

                        draggable True


                        use contact_list


            # =================================================
            # 右侧聊天窗口
            # =================================================

            use chat_window


    # ========================================================
    # 关闭按钮
    # ========================================================

    textbutton "X":

        xpos 1120

        ypos 50

        action Return()


# ============================================================
# 20. 测试入口
# ============================================================

label open_line:

    call screen chat_app

    return
default can_answer_original_case = True
default original_case_answer = ""
default original_case_solved = False


init python:

    def check_original_case_answer():

        answer = original_case_answer.strip()

        # 正确答案
        if answer == "霧谷玲衣":

            store.original_case_solved = True

            store.can_answer_original_case = False

            store.case_finished = True

            return True

        # 错误答案
        else:

            store.original_case_solved = False

            store.original_case_answer = ""

            renpy.restart_interaction

            renpy.notify(
                "结果错误，请重新输入"
            )

label reply_answer:

    $ result = renpy.call_screen("reply_case")

    if result == True:

        return

    return

screen reply_case():

    modal True

    frame:

        xsize 600
        ysize 300

        xalign 0.5
        yalign 0.5

        background "#ffffff"

        vbox:

            xalign 0.5
            ypos 35

            spacing 20


            text "请输入谁是那个偷了原稿的人":

                xalign 0.5

                size 24

                color "#333333"


            frame:

                xsize 500
                ysize 50

                background "#f5f5f5"

                input:

                    value VariableInputValue(
                        "original_case_answer"
                    )

                    xpos 10
                    ypos 5

                    xsize 480
                    ysize 40

                    size 20

                    color "#333333"


            textbutton "确定":

                xalign 0.5

                xsize 120
                ysize 50

                text_size 20

                text_color "#ffffff"

                background "#e69aaa"
                hover_background "#d98294"

                action Function(check_original_case_answer)
            textbutton "退出":

                xpos 200
                ypos 10

                action Return()
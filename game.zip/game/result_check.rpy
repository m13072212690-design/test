default can_answer_original_case = True
default original_case_answer = ""
default original_case_solved = False


init python:

    def check_original_case_answer():

        answer = store.original_case_answer.strip()

        # 正确答案
        if answer in ["霧谷玲衣", "雾谷玲衣"]:

            store.original_case_solved = True

            store.can_answer_original_case = False

            store.case_finished = True

            return True


        # 错误答案
        else:

            store.original_case_solved = False

            store.original_case_answer = ""

            renpy.notify(
                "结果错误，请重新输入"
            )

            return False

label reply_answer:

    while True:

        call screen reply_case


        # 点击输入框
        if _return == "input":

            $ original_case_answer = renpy.input(
                "请输入谁是那个偷了原稿的人：",
                default=original_case_answer,
                length=20
            ).strip()


        # 点击确定
        elif _return == "confirm":

            if check_original_case_answer():

                return


        # 点击退出
        elif _return == "close":

            return

screen reply_case():

    modal True


    frame:

        xsize 600

        ysize 300

        xalign 0.5

        yalign 0.5

        background "#ffffff"


        vbox:

            xalign 0.5

            ypos 35

            spacing 20


            text "请输入谁是那个偷了原稿的人":

                xalign 0.5

                size 24

                color "#333333"


            # 模拟输入框
            button:

                xsize 500

                ysize 50

                xalign 0.5

                background "#f5f5f5"

                action Return("input")


                if original_case_answer:

                    text original_case_answer:

                        xpos 10

                        yalign 0.5

                        size 20

                        color "#333333"


                else:

                    text "点击这里输入答案":

                        xpos 10

                        yalign 0.5

                        size 20

                        color "#888888"


            textbutton "确定":

                xalign 0.5

                xsize 120

                ysize 50

                text_size 20

                text_color "#ffffff"

                background "#e69aaa"

                hover_background "#d98294"

                action Return("confirm")


            textbutton "退出":

                xpos 200

                ypos 10

                action Return("close")
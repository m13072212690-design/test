﻿# 游戏的脚本可置于此文件中。

# 声明此游戏使用的角色。颜色参数可使角色姓名着色。


# 游戏在此开始。

transform character_left:
    xpos 0
    ypos 75

transform character_right:
    xpos 600
    ypos 125

label start:

    scene room

    "2027年1月21日 晚"

    show saki_normal at character_right
    "我叫望月咲，是宇多川出版社的一名新人编辑"
    "前不久刚刚解决了因《鬨之声》这本小说所出现的书灵事件，得到上司的一致好评，目前的社畜人生可谓是一片光明...大概"
    "所谓书灵，顾名思义就是书中角色所幻化出来的生命体，在当今这个社会虽说并不算常见，但作为出版社编辑，平时也少不了和他们打交道"
    
    show rei_normal at character_left
    rei "小咲？"
    "这位就是书灵，她叫做霧谷玲衣，从一本名叫《颜面球杀人事件》的悬疑小说中幻化而来，不知为何现在依存在我的电脑之中"
    show rei_cur at character_left
    rei "喂？...小咲？...望月编辑？..."
    show saki_shock at character_right
    saki "嗯？抱歉，刚刚没注意到，怎么了吗？"
    hide rei_cur
    hide saki_shock
    show rei_normal at character_left
    show saki_normal at character_right
    rei "没什么，你的邮件响了，不去看一眼吗？"

    scene bg pc
    call screen email

    scene room
    show saki_puz at character_right
    saki "原稿不见了？怎么会发生这种事情？而且我的电脑要怎么能查到一般人查不到的东西啊...难道说？"
    show rei_happy at character_left
    rei "哼哼~~是在说我吧"
    saki "玲衣吗？对哦，你在电脑里待着是不是可以看到很多我们看不到的东西"
    hide saki_puz
    hide rei_happy
    show rei_normal at character_left
    show saki_normal at character_right
    rei "嘛...也不能这么说，但我的确有一些特殊的方法"
    rei "毕竟从某种意义上来说，唯香也算是创造了我的人，我们就帮一下她吧，我来教小咲怎么利用chappy来进行搜查"
    saki "(对哦，小山内老师是《颜面球杀人事件》的作者，对玲衣来说应该很重要吧)"
    show saki_wdl at character_right
    saki "等等...为什么是我来？？你直接解决不可以吗"
    show rei_smile at character_left
    rei "嗯哼~"    

    scene bg pc
    hide saki_wdl
    hide rei_smile
    "接下来将进入搜查模式，您可以自由的查看电脑上的软件，寻找可能和案情有关的关键词，将其输入到chappy中"
    "霧谷玲衣会根据你输入的关键词在网络中搜寻相关的内容\n注：只有正确的关键词才会提供相关信息，输入内容不要带有空格，输入后点击回车返回"
    #保持搜查模式
    while not case_finished:

        call screen computer_desktop


    scene room
    show rei_normal at character_left
    show saki_shock at character_right
    rei "......"
    "我略有些愤怒的看着电脑屏幕中的白衣少女，这样一来就说得通为什么她可以这么精准的帮我找到每一条线索，原来这一切都是玲衣的有意引导。"
    hide saki_shock
    show saki_puz at character_right
    saki "玲衣，你为什..."
    "我话刚说出口，就被玲衣打断了。"
    rei "在小咲的认知中，书灵是怎么样的存在呢？"
    hide saki_puz
    show saki_cur at character_right
    saki "现在问这个干什么...书灵不就是指的像你这种从书中幻化到现世之中的特殊生命体吗？"
    hide saki_cur
    show saki_normal at character_right
    rei "嘛...这么说的确没错。不过，我想说的其实是，书灵和你们人类不同，不需要依靠碳水过活，对于我们来说，真正是食粮是——“故事”"
    hide rei_normal
    show rei_happy at character_left
    rei "就像稻葉京花一样，她诞生自充满青春与汗水的校园故事，那么她自然也会去追求这样的故事。而我，我是源自于一本悬疑小说，那么你觉得我会追求什么样的故事呢？"
    saki "悬疑...？但是，这又和我现在要问你的事情有什么关系，小山内老师应该对你来说也很特殊吧，为什么要偷她的原稿？"
    hide rei_happy
    show rei_cur at character_left
    rei "你是说这个？"
    hide rei_cur
    show rei_normal at character_left
    hide saki_normal
    show saki_shock at character_right
    "刹那间，一个名为原稿的文件出现在我的电脑桌面上，然后瞬间又再次消失。"
    "正在我刚想质问玲衣文件去哪里的时候，突然又收到了一封新邮件，是小山内老师发给我的。"
    yuika "太感谢你了望月老师！！这就是我的原稿，真的是救人于水火啊 ！有空请务必让我请你吃饭！！"
    saki "这..."
    hide rei_normal
    show rei_smile at character_left
    hide saki_shock
    show saki_normal at character_right
    rei "原稿并不重要，我只是从那个冒失的大作家那里借用了一下罢了。不过还是要感谢一下紬肯帮我这个忙，把寄存在手机里的我带过去，让我有机会可以跑到作家桑的电脑里~"
    "似乎看穿了我的疑惑，玲衣继续说"
    rei "不用担心，文档我没动过手脚，就像我刚刚说的，我追求的只是这个“悬疑”的过程，结果如何我并不在意"
    hide saki_normal
    show saki_puz at character_right
    saki "所以你是为了进食才...？"
    hide rei_smile
    show rei_normal at character_left
    rei "嗯...也不全是，毕竟我们的进食对象只要是故事就好，种类的话只会影响口味。"
    rei "只是，对于我来说，在我进食到“悬疑”类的故事之后，我能够获得更强大的力量"
    hide saki_puz
    show saki_normal at character_right
    saki "你...要做什么"
    "我有些紧张，这个看起来就很神秘的少女，在原作中就一直被主角怀疑是连环杀人案的凶手，虽然最后故事描述的真相是，这起案件只不过是一群利欲熏心的匪徒间的自相残杀，但仍有不少读者怀疑这一切都是她挑唆的。"
    "我怎么可以忘了呢，霧谷玲衣就是这样一个神秘又危险的人，是因为最近和她相处太久放松警惕了吗"
    "当我回过神来，又对上玲衣那双似笑非笑的眼睛。这之后她的眼睛往时钟的方向瞥了一眼。"
    hide rei_normal
    show rei_smile at character_left
    rei "时间正好~与其听我说，小咲还是自己直接来看吧"
    saki "时间？"
    hide rei_smile
    "听了她的话之后，我也去看了一眼表，刚刚正好过了零点，现在已经是第二天，1月22日了。等等...这个日期..."
    "嘭嘭！！"
    hide saki_normal
    show saki_shock at character_right
    saki "欸？！"
    "我循着声音的来源看去，却看到的只是一个适中大小的生日蛋糕，静静的躺在我的桌子上，屏幕上是玲衣有点得意的表情"
    show rei_happy at character_left
    rei "选好目标，然后对准准心，完成，不愧是我~"
    hide saki_shock
    show saki_shy at character_right
    saki "所以，你是为了......"
    rei "今天是你的生日对吧，我本来只是想尝试一下的，没想到真的可行"
    saki "啊...不对，首先，你是怎么知道我的生日的，我记得好像没跟你提过吧"
    rei "我就在你的电脑里啊，想知道这个还是很容易的"
    hide saki_shy
    show saki_shock at character_right
    saki "好吧，等等...你偷看我的个人信息！"
    rei "小咲这就是冤枉我了~我就在这里，有些东西就算不想看到也会被动接收到的~"
    saki "好吧...那还有就是，下次不能做这种会对别人造成困扰的事情了！"
    hide saki_shock
    show saki_normal at character_right
    rei "好好我知道了，下次我会提前告知对方的~"
    saki "我不是这个意思...算了..."
    hide saki_normal
    show saki_shy at character_right
    saki "嘛...总之，还是谢谢你..."
    rei "哼哼，不用谢，我在小咲这里借住了这么久，也应该回报小咲一下~哟咻"
    hide saki_shy
    show saki_shock at character_right
    saki "呜哇！你突然从电脑里钻出来干什么"
    rei "我也想尝尝自己的劳动成果究竟是什么味道的哎~~"
    hide saki_shock
    show saki_shy at character_right
    hide rei_happy
    show rei_normal at character_left
    "突然被她这么近距离的盯着，不知道为什么我突然有点不好意思"
    saki "那你等等我去拿两份餐具过来......好了，开始吃吧"
    hide saki_shy
    show saki_normal at character_right
    "我将蛋糕切好，分给了玲衣和自己一块，吃了一口后，我们不约而同的看向对方"
    hide saki_normal
    show saki_shock at character_right
    hide rei_normal
    show rei_happy at character_left
    allc "好吃！！"
    saki "这也太实惠了吧，不用花钱就可以吃到这么美味的蛋糕！玲衣，要不以后也拜托你了！"
    hide rei_happy
    show rei_smile at character_left
    rei "等等等等，刚刚小咲不还说让我不要再做这种事情了吗~"
    hide saki_shock
    show saki_shy at character_right
    saki "这个..."
    hide saki_shy
    show saki_normal at character_right
    hide rei_smile
    show rei_normal at character_left
    rei "不过我确实能懂你的心情啦"
    saki "在告知目标的前提下的话，嗯，我觉得，也不是不可以这样做就是了"
    rei "好~那我们以后再说"
    rei "不过，现在还是让我再说一句"
    rei "…………"
    hide saki_normal
    hide rei_normal
    unknown "生日快乐……瞳月"

    "——END——"

    return

label open_search:

    call screen search_clue

    return

screen search_clue():

    modal True

    frame:

        xsize 1100
        ysize 650

        xpos 90
        ypos 35


        background "#eeeeee"


        hbox:

            # 左侧邮件列表

            frame:

                xsize 350
                ysize 650

                background "#dddddd"


                vbox:


                    text "词条目录"


                    for clue in clues:

                        if clue["unlocked"] == True:
                            textbutton clue["name"]:

                                action SetVariable(
                                    "current_clue",
                                    clue["id"]
                                )



            # 右侧邮件内容

            frame:

                xsize 750
                ysize 650


                background "#ffffff"


                use clue_content
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

screen clue_content():


    $ clue = clues[current_clue]


    vbox:


        spacing 15


        text clue["name"]

        null height 20

        text clue["brief"]

        null height 20

        text "note: [clue['note']]"
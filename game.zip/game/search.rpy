label open_search:

    call screen search_clue

    return

screen search_clue():

    modal True

    frame:

        xsize 1100
        ysize 650

        xpos 90
        ypos 35


        background "#eeeeee"


        hbox:

            # 左侧邮件列表

            frame:

                xsize 350
                ysize 640

                background "#dddddd"


                vbox:


                    text "{b}词条目录{/b}":
                        xpos 50
                        size 25

                    null height 5
                    for clue in clues:

                        if clue["unlocked"] == True:
                            textbutton clue["name"]:
                                xpos 30
                                action SetVariable(
                                    "current_clue",
                                    clue["id"]
                                )



            # 右侧邮件内容

            frame:

                xsize 740
                ysize 640


                background "#ffffff"


                use clue_content
    textbutton "X":

        xpos 1120
        ypos 50

        action Return()

screen clue_content():


    $ clue = clues[current_clue]


    vbox:


        spacing 15


        text clue["name"]:
            xpos 200
            size 25

        null height 15

        text clue["brief"]

        null height 15

        text "note:"
        text "[clue['note']]"
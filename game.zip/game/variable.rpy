default current_email = 0

default case_finished = False

default found_clues = []

default final = False

default nishihara = False

default current_clue = 0



